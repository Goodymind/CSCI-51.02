int dummy1 (int x) {
    return x * 4;
}

int dummy2 (int x) {
    return x * 41;
}

int dummy3 (int x) {
    return x * 63;
}

int dummy4 (int x) {
    return x * -5;
}

int dummy5 (int x) {
    return x * 61;
}



